package com.ponto.controledeponto

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.button.MaterialButton

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Botão para o fragmento Calendar
        val calendarBtn: MaterialButton = view.findViewById(R.id.btnCalendar)
        calendarBtn.setOnClickListener{
            val fragment = CalendarFragment()
            val transaction = parentFragmentManager.beginTransaction()
            transaction.replace(R.id.nav_container, fragment).commit()
        }

        // Botão para o fragmento Report
        val reportBtn: MaterialButton = view.findViewById(R.id.btnReport)
        reportBtn.setOnClickListener{
            val fragment = ReportFragment()
            val transaction = parentFragmentManager.beginTransaction()
            transaction.replace(R.id.nav_container, fragment).commit()
        }

        // Botão para o fragmento Config
        val configBtn: MaterialButton = view.findViewById(R.id.btnConfig)
        configBtn.setOnClickListener{
            val fragment = ConfigFragment()
            val transaction = parentFragmentManager.beginTransaction()
            transaction.replace(R.id.nav_container, fragment).commit()
        }

        // Botão para o fragmento Check-in
        val checkinBtn: MaterialButton = view.findViewById(R.id.btnCheckin)
        checkinBtn.setOnClickListener{
            val fragment = CheckinFragment()
            val transaction = parentFragmentManager.beginTransaction()
            transaction.replace(R.id.nav_container, fragment).commit()
        }

        return view
    }
}
